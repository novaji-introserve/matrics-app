#!/usr/bin/env bash

set -euo pipefail

LOG_PATH="/opt/seatunnel/logs/seatunnel-engine-server.log"
LINES=50
FOLLOW=false
LEVEL=""
JOB_ID=""

usage() {
  echo "Usage: $0 [-f] [-n LINES] [-l LEVEL] [-j JOB_ID]"
  echo "  -f          Follow log output (like tail -f)"
  echo "  -n LINES    Number of lines to show (default: 50)"
  echo "  -l LEVEL    Filter by log level: ERROR, WARN, INFO"
  echo "  -j JOB_ID   Filter by job ID"
  exit 0
}

while getopts "fn:l:j:h" opt; do
  case $opt in
    f) FOLLOW=true ;;
    n) LINES="$OPTARG" ;;
    l) LEVEL="${OPTARG^^}" ;;
    j) JOB_ID="$OPTARG" ;;
    h) usage ;;
    *) usage ;;
  esac
done

build_grep() {
  local cmd="cat"
  [[ -n "$LEVEL" ]]  && cmd="$cmd | grep -a \" $LEVEL \""
  [[ -n "$JOB_ID" ]] && cmd="$cmd | grep -a \"$JOB_ID\""
  echo "$cmd"
}

GREP=$(build_grep)

if $FOLLOW; then
  docker compose exec seatunnel bash -c "tail -f -n ${LINES} ${LOG_PATH} | ${GREP}"
else
  docker compose exec seatunnel bash -c "tail -n ${LINES} ${LOG_PATH} | ${GREP}"
fi
