#!/usr/bin/env bash
# One-time full snapshot of the contacts table.
# Risk assessment is skipped for all rows (skip_risk=true).
# Run this once before switching to contacts.sh for ongoing CDC.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -f "${SCRIPT_DIR}/.env" ]]; then
  set -a
  # shellcheck disable=SC1091
  source "${SCRIPT_DIR}/.env"
  set +a
fi

: "${MYSQL_USER:?Set MYSQL_USER before running this script}"
: "${MYSQL_PASSWORD:?Set MYSQL_PASSWORD before running this script}"

SERVER_ID_RANGE_WIDTH=4
SERVER_ID_BASE=$(( ( $(date +%s%N) + $$ + RANDOM ) % 4000000000 + 10000 ))
SERVER_ID_END=$((SERVER_ID_BASE + SERVER_ID_RANGE_WIDTH - 1))
SERVER_ID="${SERVER_ID_BASE}-${SERVER_ID_END}"

docker compose exec seatunnel bash -lc '
  /opt/seatunnel/bin/seatunnel.sh \
    -c /opt/seatunnel/custom/seatunnel/conf/contacts_snapshot.conf \
    -i mysql.jdbc.url="jdbc:mysql://host.docker.internal:3306/suitecrm" \
    -i mysql.username="'"${MYSQL_USER}"'" \
    -i mysql.password="'"${MYSQL_PASSWORD}"'" \
    -i server.id="'"${SERVER_ID}"'" \
    -i server.timezone="America/Toronto" \
    --async
'
