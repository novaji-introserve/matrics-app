import logging
import random
import time
from functools import lru_cache, wraps
from typing import Any, Sequence

from odoo_connect.explore import explore

from config import get_odoo_client
from config.logger import setup_job_logging

logger = logging.getLogger("app")
TRACKING_FIELDS = ["email", "phone", "bvn", "customer_id"]

LOAD_FIELDS = [
    "customer_id", "name", "firstname", "lastname",
    "phone", "mobile", "bvn", "email", "dob",
    "registration_date", "branch_id", "region_id",
    "origin", "country_id", "sector_id", "education_level_id",
]
_CACHE_TTL = 3600  # 1 hour — static Odoo lookups rarely change

_QUEUE_RISK_HIGH = "risk-high"
_QUEUE_RISK_LOW = "risk-low"


def _ttl_cache(ttl: int = _CACHE_TTL):
    """Per-process TTL cache for zero-argument functions."""
    def decorator(fn):
        _state = {}

        @wraps(fn)
        def wrapper():
            now = time.monotonic()
            if "value" in _state and now < _state["expires_at"]:
                return _state["value"]
            _state["value"] = fn()
            _state["expires_at"] = now + ttl
            return _state["value"]

        return wrapper
    return decorator


def get_env():
    return get_odoo_client()


def run_risk_assessment(p_customer_id: int, priority: int = 10) -> Any:
    if p_customer_id <= 0:
        raise ValueError("p_customer_id must be a positive integer")
    env = get_env()
    partner_model = env["res.partner"]
    return partner_model.action_enqueue_risk_score_with_plan([p_customer_id], priority)


def _enqueue_risk(partner_id: int, customer_id: str | None, queue_name: str) -> None:
    from repo.risk import assess_risk, ODOO_PRIORITY_HIGH, ODOO_PRIORITY_LOW
    from router.utils import get_rq_queue
    odoo_priority = ODOO_PRIORITY_HIGH if queue_name == _QUEUE_RISK_HIGH else ODOO_PRIORITY_LOW
    get_rq_queue(queue_name).enqueue(assess_risk, partner_id, customer_id, odoo_priority)


def capture_changes(change: dict) -> Any:
    env = get_env()
    change_model = env["change.data.capture"]
    change_id = change_model.create(change)
    return change_id


@lru_cache(maxsize=256)
def get_resource_uri_id(model_uri: str, name: str) -> int:
    env = get_env()
    resource_model = env["res.resource.uri"]
    resource_ids = resource_model.search([("model_uri", "=", model_uri)], limit=1)
    if resource_ids:
        return resource_ids[0]
    return resource_model.create(
        {
            "model_uri": model_uri,
            "name": name,
        }
    )


@_ttl_cache()
def get_tracked_partner_fields() -> list[dict[str, Any]]:
    env = get_env()
    field_model = env["ir.model.fields"]
    field_ids = field_model.search(
        [
            ("model", "=", "res.partner"),
            ("tracking", "!=", None),
            ("tracking", "!=", 0),
            ("name", "in", TRACKING_FIELDS),
        ]
    )
    if not field_ids:
        return []
    return field_model.read(field_ids, ["name", "field_description"])


def normalize_comparison_value(value: Any) -> Any:
    if isinstance(value, (list, tuple)):
        if len(value) == 2 and not isinstance(value[0], (list, tuple, dict)):
            return value[0]
        return list(value)
    return value


def stringify_change_value(value: Any) -> str:
    if value in (None, False):
        return ""
    if isinstance(value, (list, tuple)):
        if len(value) == 2:
            return str(value[1])
        return ", ".join(str(item) for item in value)
    return str(value)


def capture_tracked_partner_changes(
    partner_id: int,
    old_record: dict[str, Any],
    new_record: dict[str, Any],
    tracked_fields: list[dict[str, Any]],
) -> None:
    for tracked_field in tracked_fields:
        field_name = tracked_field.get("name")
        if not field_name or field_name not in new_record:
            continue

        old_value = normalize_comparison_value(old_record.get(field_name))
        new_value = normalize_comparison_value(new_record.get(field_name))
        if old_value == new_value:
            continue

        change = {
            "name": f"Change in {field_name}",
            "model_id": "res.partner",
            "res_id": partner_id,
            "res_name": new_record.get("name", ""),
            "resource_id": get_resource_uri_id("res.partner", "Customer"),
            "field_name": field_name,
            "old_val": stringify_change_value(old_record.get(field_name)),
            "new_val": stringify_change_value(new_record.get(field_name)),
        }
        capture_changes(change)


def build_partner_record(payload: dict[str, Any]) -> dict[str, Any]:
    customer_id = payload.get("id")
    email = payload.get("email") or (
        f"{payload.get('first_name', 'unknown').lower()}."
        f"{payload.get('last_name', 'unknown').lower()}@example.com"
    )
    return {
        "name": f"{payload.get('first_name')} {payload.get('last_name')}",
        "customer_id": customer_id,
        "firstname": payload.get("first_name"),
        "lastname": payload.get("last_name"),
        "phone": str(payload.get("phone_work")),
        "mobile": str(payload.get("phone_mobile")),
        "bvn": customer_id,
        "email": email,
        "dob": payload.get("birthdate")[:10] if payload.get("birthdate") else None,
        "registration_date": (
            payload.get("date_entered")[:10] if payload.get("date_entered") else None
        ),
    }


@_ttl_cache()
def get_branch_ids() -> list[int]:
    env = get_env()
    branches = explore(env["res.branch"])
    return [b.id for b in branches.search([])]


def get_branch(id):
    env = get_env()
    return explore(env["res.branch"]).search([("id", "=", id)], limit=1)


@lru_cache(maxsize=256)
def get_branch_region_id(branch_id: int | None) -> int | None:
    if not branch_id:
        return None
    env = get_env()
    branch_model = env["res.branch"]
    branch_data = branch_model.read([branch_id], ["region_id"])
    if not branch_data:
        return None
    region_value = branch_data[0].get("region_id")
    if isinstance(region_value, (list, tuple)):
        return region_value[0] if region_value else None
    return region_value


@_ttl_cache()
def get_education_level_ids() -> list[int]:
    env = get_env()
    education_levels = explore(env["res.education.level"])
    return [e.id for e in education_levels.search([])]


@_ttl_cache()
def get_sector_ids() -> list[int]:
    env = get_env()
    sectors = explore(env["res.partner.sector"])
    return [s.id for s in sectors.search([])]


@_ttl_cache()
def get_country_ids() -> list[int]:
    env = get_env()
    countries = explore(env["res.country"])
    return [c.id for c in countries.search([("code", "=", "NG")])]


def build_create_partner_extra_fields() -> dict[str, Any]:
    country_ids = get_country_ids()
    sector_ids = get_sector_ids()
    education_level_ids = get_education_level_ids()
    branch_ids = get_branch_ids()
    branch_id = random.choice(branch_ids) if branch_ids else None
    return {
        "branch_id": branch_id,
        "region_id": get_branch_region_id(branch_id),
        "origin": "prod",
        "country_id": random.choice(country_ids) if country_ids else None,
        "sector_id": random.choice(sector_ids) if sector_ids else None,
        "education_level_id": (
            random.choice(education_level_ids) if education_level_ids else None
        ),
    }


def _payload_to_row(payload: dict[str, Any], extra: dict[str, Any]) -> list:
    record = build_partner_record(payload)
    merged = {**record, **extra}
    return [merged.get(f) for f in LOAD_FIELDS]


def bulk_add_partners(payloads: Sequence[dict]) -> dict[str, Any]:
    setup_job_logging()
    logger.info("Starting bulk partner load for %d records", len(payloads))
    try:
        extra = build_create_partner_extra_fields()
        data = [_payload_to_row(p, extra) for p in payloads]
        env = get_env()
        partner_model = env["res.partner"]
        result = partner_model.action_bulk_load_partners(LOAD_FIELDS, data)
        created = len(result.get("ids") or [])
        errors = len(result.get("messages") or [])
        logger.info("Bulk load complete: created=%d errors=%d", created, errors)
        return result
    except Exception:
        logger.exception("Bulk partner load failed for %d records", len(payloads))
        raise


def action_add_pep(p_customer_id: int) -> Any:
    if p_customer_id <= 0:
        raise ValueError("p_customer_id must be a positive integer")
    env = get_env()
    partner_model = env["res.partner"]
    return partner_model.action_add_pep([p_customer_id])


def get_total_partners():
    env = get_env()
    partner_model = env["res.partner"]
    return partner_model.search_count([])


def get_partner_with_customer_id(customer_id):
    env = get_env()
    return explore(env["res.partner"]).search(
        [("customer_id", "=", customer_id)], limit=1
    )


def get_partner(partner_id):
    env = get_env()
    return explore(env["res.partner"]).search([("id", "=", partner_id)], limit=1)


def refresh(model, res_id):
    env = get_env()
    rec = explore(env[model]).search([("id", "=", res_id)], limit=1)
    if rec:
        rec.invalidate_cache()


def add_partner(payload: dict, skip_risk: bool = False) -> int:  # noqa: FBT001
    setup_job_logging()
    customer_id = payload.get("id")
    try:
        logger.info("Starting partner sync for customer_id=%s", customer_id)
        env = get_env()
        partner_model = env["res.partner"]
        partner_record = build_partner_record(payload)
        existing_partner_ids = (
            partner_model.search([("customer_id", "=", customer_id)], limit=1)
            if customer_id
            else []
        )
        if existing_partner_ids:
            tracked_fields = get_tracked_partner_fields()
            tracked_field_names = [
                field["name"]
                for field in tracked_fields
                if field.get("name") in partner_record
            ]
            old_record = {}
            if tracked_field_names:
                old_records = partner_model.read(
                    existing_partner_ids, tracked_field_names
                )
                old_record = old_records[0] if old_records else {}

            partner_model.write(existing_partner_ids, partner_record)
            partner_id = existing_partner_ids[0]
            if tracked_fields and old_record:
                capture_tracked_partner_changes(
                    partner_id=partner_id,
                    old_record=old_record,
                    new_record=partner_record,
                    tracked_fields=tracked_fields,
                )
            # Odoo's write() override triggers risk via queue_job when tracking
            # fields change — no separate enqueue needed here.
            logger.info(
                "Updated partner from sync customer_id=%s partner_id=%s",
                customer_id,
                partner_id,
            )
            return partner_id

        create_record = {**partner_record, **build_create_partner_extra_fields()}
        create_record["origin"] = "prod"
        partner_id = partner_model.create(create_record)
        # Risk is already computed inline by Odoo's create() override —
        # no separate queue_job needed for new customers.
        logger.info(
            "Created partner from sync customer_id=%s partner_id=%s",
            customer_id,
            partner_id,
        )
        return partner_id
    except Exception:
        logger.exception("Partner sync failed for customer_id=%s", customer_id)
        raise
