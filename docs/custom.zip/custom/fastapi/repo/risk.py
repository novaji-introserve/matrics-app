import logging

from repo.partner import run_risk_assessment

logger = logging.getLogger("app")

QUEUE_HIGH = "risk-high"
QUEUE_LOW = "risk-low"

# Maps to queue_job priority on the Odoo side (higher = runs sooner)
ODOO_PRIORITY_HIGH = 20  # onboarding: runs before background jobs
ODOO_PRIORITY_LOW = 10   # CDC update: default background priority


def assess_risk(partner_id: int, customer_id: str | None = None, odoo_priority: int = ODOO_PRIORITY_LOW) -> None:
    try:
        run_risk_assessment(partner_id, odoo_priority)
    except Exception:
        logger.exception(
            "Risk assessment failed for partner_id=%s customer_id=%s",
            partner_id,
            customer_id,
        )
