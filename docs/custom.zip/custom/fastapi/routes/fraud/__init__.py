from .routes import router

PREFIX = "/fraud"
TAGS = ["Fraud"]
