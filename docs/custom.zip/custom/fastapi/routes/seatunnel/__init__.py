from .routes import router

PREFIX = "/seatunnel"
TAGS = ["SeaTunnel"]
