from typing import Any

from fastapi import APIRouter, Body

router = APIRouter()


@router.post("/sink")
async def seatunnel_sink(request_body: Any = Body(...)) -> dict:
    return {"status": "received", "rows": len(request_body) if isinstance(request_body, list) else 1}
