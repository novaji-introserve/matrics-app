from .routes import router

PREFIX = "/sync"
TAGS = ["Sync"]
