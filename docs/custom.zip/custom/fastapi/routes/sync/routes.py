import logging
from typing import Any

from fastapi import APIRouter, Body, Query

from repo.partner import add_partner, bulk_add_partners
from router.utils import get_rq_queue

router = APIRouter()
logger = logging.getLogger("app")


@router.post("/contacts")
async def sync_contacts(
    payload: Any = Body(...),
    skip_risk: bool = Query(False, description="Skip risk assessment (use during initial snapshot sync)"),
) -> dict[str, object]:
    records = payload if isinstance(payload, list) else [payload]
    queue = get_rq_queue("sync")

    if skip_risk and len(records) > 1:
        # Snapshot batch: one load() call instead of N individual creates
        job = queue.enqueue(bulk_add_partners, records)
        logger.info("Queued bulk partner load job for %d records", len(records))
        return {"status": "accepted", "queued": 1, "mode": "bulk"}

    jobs = [queue.enqueue(add_partner, dict(record), skip_risk) for record in records]
    logger.info("Queued %d partner sync job(s) skip_risk=%s", len(jobs), skip_risk)
    return {"status": "accepted", "queued": len(jobs), "mode": "individual"}
